﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using System;


public class one_player : MonoBehaviour {

    public Image image1;
    public Image[] image2;
    public InputField p2;
    public Text err2;
    
    public static int a2 = 0;

    // Use this for initialization
    void Start()
    {
            if (image1.enabled == true)
                image1.enabled = false;
        for (int i = 0; i < image2.Length; i++)
            if (image2[i].enabled == true)
                image2[i].enabled = false;
        image1.enabled = true;
        image2[0].enabled = true;
        err2.enabled = false;
        n2 = "";
    }

    // Update is called once per frame
    void Update()
    {

    }
    public void onchange2()
    {
        image2[a2].enabled = false;
        if (a2 == image2.Length - 1)
        {
            a2 = 0;
        }
        else
        {
            a2++;
        }
        image2[a2].enabled = true;
    }

    

    public void textedit2(string s)
    {
        n2 = s;
    }
    public static string n2 = "P_2";
    public void proceedToToss()
    {
       
        err2.enabled = false;
       
        
        if (n2.Trim() == "")
        {
            err2.enabled = true;
        }
        
        else
        {
            
            err2.enabled = false;
           
            Debug.Log("OK");
            Application.LoadLevel("toss_1");
        }

    }
}
