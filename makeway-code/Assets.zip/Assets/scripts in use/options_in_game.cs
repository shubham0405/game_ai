﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class options_in_game : MonoBehaviour {

    public GameObject menu;
    public GameObject pause;
    public GameObject on;
    public GameObject off;

    public void onClickenter()
    {
        menu.active = true;
        pause.active = false;
        if (PlayerPrefs.GetFloat("audio") == 0)
            off.active = false;
        else
            on.active = false;
    }

    public void OnExitenter()
    {
        menu.active = false;
        pause.active = true;
        on.active = true;
        off.active = true;
    }
}
