﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class audioSetup : MonoBehaviour {

    public AudioSource asa;
	// Use this for initialization
	void Start () {
		asa.volume= PlayerPrefs.GetFloat("audio");
    }
	
	// Update is called once per frame
	void Update () {
		asa.volume= PlayerPrefs.GetFloat("audio"); ;
    }
}
