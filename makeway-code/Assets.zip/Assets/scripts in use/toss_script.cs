﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class toss_script : MonoBehaviour {

    //public Canvas p1;
    public Canvas p2;
    public Canvas but;
    public Canvas but2;
    public Text t1;
    public Player_icon p;
    public GameObject coin;
    public GameObject coin2;
    public Image img;
    public Image[] image1;
    public Image[] image2;
    public Dropdown d1;
    public GameObject text;
    // Use this for initialization
    void Start() {
        Debug.Log("asffg");
        text.active = false;
        for (int i = 0; i < image1.Length; i++)
            if (image1[i].enabled == true)
                image1[i].enabled = false;
        for (int i = 0; i < image2.Length; i++)
            if (image2[i].enabled == true)
                image2[i].enabled = false;
       /* GameObject script = GameObject.Find("gameobject");
        p = script.GetComponent<Player_icon>();*/
       // t1.enabled = false;
        //d1.enabled = false;
       if(but2.enabled==true)
        but2.enabled = false;
        
    }
    public void dd_edit(int a)
    {
        chance = a;
        Debug.Log(chance);
    }
     void Update()
    {
        coin.transform.Rotate(0, 3000f * Time.deltaTime, 0, Space.World);
    }
    public void on_click()
    {
        but.enabled = false;
        coin.active = true;
       but2.enabled = true;
    }
    public static int i=0;
    public static int chance = 0;
    public static string p1_name=Player_icon.n1;
    public static string p2_name = Player_icon.n2;


    public void stop()
    {
        coin.active = false;
        coin2.active = true;
         i = UnityEngine.Random.Range(0, 2);
        string name="";
        if (i == 0)
        {
            name = Player_icon.n1;
            image1[Player_icon.a1].enabled=true;
        }
        else if(i==1)
        {
            name = Player_icon.n2;
            image2[Player_icon.a2].enabled = true;
        }
        text.active = true;
        t1.enabled = true;
        d1.enabled = true;
        but2.enabled = false;
       
        
        t1.text= "Congratulation !!\n"+name+" won the toss\nChoose your color: ";
    }
}
