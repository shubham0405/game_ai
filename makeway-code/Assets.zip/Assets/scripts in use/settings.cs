﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;
using UnityEngine.UI;
using UnityEngine.Audio;

public class settings : MonoBehaviour {

   // public AudioMixer am;
    public Slider s;
      
    public void Start()
    {
        s.value = PlayerPrefs.GetFloat("audio");
    }
    public void Update()
    {
        PlayerPrefs.SetFloat("audio", s.value);

    }

    public void volumePrefs()
    {
        PlayerPrefs.SetFloat("audio", s.value);
    }
}
