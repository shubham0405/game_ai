﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class colorchange : MonoBehaviour {

    public Renderer rend;
    public Material[] mat;
    public Material startcolor;
    public bool done = true;
    public AudioClip sound;
    public AudioSource source;
    public random_points r;
	// Use this for initialization
	void Start () {
        rend = GetComponent<Renderer>();
        GameObject script = GameObject.Find("points generator");
        r = script.GetComponent<random_points>();
        source = GetComponent<AudioSource>();
        source.loop = false;
    }
    private void Update()
    {
        source.volume= PlayerPrefs.GetFloat("audio");
       
    }

    /* int give_color()
     {
         int chance=0;
         int count = 0;
         for(int i=0;i<27;i++)
         {
             for(int j=i+1;j<27;j++)
             {
                 if (r.conn[i, j] == 10)
                     count++;
                 else if (r.conn[i, j] == -10)
                     count--;
             }
         }
         if (count == 0)
             return 0;
         else if (count == 1)
             return 1;
         else
             return -1;

     }*/
    // Update is called once per frame
    void OnMouseDown()
    {
        
        
        
            int turn = 1000;
            if (Input.GetMouseButtonDown(0))
            {
                if (done && r.text==1)
                {
                     source.Play();
                    turn = r.chance;
                    if (r.chance == 0) r.chance = 1;
                    else r.chance = 0;
                done = false;
                    rend.material = mat[turn];
                }
            }
            for (int i = 0; i < 27; i++)
            {
                for (int j = i + 1; j < 27; j++)
                {
                    if (r.cylinder[i, j] == gameObject && turn == 1)
                    {
                        Debug.Log("f");
                        r.conn[i, j] = -10;
                        r.conn[j, i] = -10;
                    }
                    if (r.cylinder[i, j] == gameObject && turn == 0)
                    {
                        r.conn[i, j] = 10;
                        r.conn[j, i] = 10;
                    }
                }
            }
        
    }
    void OnMouseEnter()
    {
        if (done && r.text==1)
        {
            startcolor = rend.material;
            rend.material = mat[r.chance];
        }
    }
    void OnMouseExit()
    {
        if(done && r.text==1)
        rend.material = startcolor;
    }

}
