﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
public class ai_predict : MonoBehaviour {

    public Text t1,t2;
    public Camera cam; 
	// Use this for initialization
	void Start () {
        int win = ai_random_points.win_page;
        if(win==2)
        {
            t1.text = "GOTCHA !!";
            t2.text = "YOU LOSE !";
            cam.backgroundColor = Color.blue;
        }
        else if(win==3)
        {
            t1.text = "CONGRATULATIONS !!";
            t2.text = "YOU DEFEATED COMPUTER !";
            cam.backgroundColor = Color.red;
        }
        else
        {
            t1.text = "TOUGH GAME !!";
            t2.text = "NO RESULT !";
            //cam.backgroundColor = Color.green;
        }
    }
	
	
}
