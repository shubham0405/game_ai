﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class sound_icon_alter : MonoBehaviour {

    public GameObject on;
    public GameObject off;
	public void call()
    {
        if(on.active == true)
        {
            on.active = false;
            off.active = true;
        }
        else
        {
            off.active = false;
            on.active = true;
        }
    }
}
