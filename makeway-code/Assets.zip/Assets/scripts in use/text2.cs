﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine.UI;
using UnityEngine;

public class text2 : MonoBehaviour {

    public Text t1;
    // Use this for initialization
    void Start()
    {
        t1.text = random_points.n2 + " WON THE GAME !!";
    }

    // Update is called once per frame
    void Update () {
		
	}
}
