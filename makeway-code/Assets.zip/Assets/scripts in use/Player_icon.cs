﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using System;

public class Player_icon : MonoBehaviour {

    public Image[] image1;
    public Image[] image2;
    public InputField p1;
    public InputField p2;
    public Text err1;
    public Text err2;
    public Text err3;
    public static int a1 = 0;
    public static int a2 = 0;

    // Use this for initialization
    void Start () {
        for (int i = 0; i < image1.Length; i++)
            if(image1[i].enabled==true)
                image1[i].enabled = false;
        for (int i = 0; i < image2.Length; i++)
            if (image2[i].enabled == true)
                image2[i].enabled = false;
        image1[0].enabled = true;
        image2[0].enabled = true;
        err1.enabled = false;
        err2.enabled = false;
        err3.enabled = false;
        n1 = "";
        n2="";
    }
	
	// Update is called once per frame
	void Update ()
    {
		
	}

    
    public void onchange1()
    {
        image1[a1].enabled = false;
        if(a1==image1.Length-1)
        {
            a1 = 0;
        }
        else
        {
            a1++;
        }
        image1[a1].enabled = true;
    }
    public void onchange2()
    {
        image2[a2].enabled = false;
        if (a2 == image2.Length - 1)
        {
            a2 = 0;
        }
        else
        {
            a2++;
        }
        image2[a2].enabled = true;
    }

    public void textedit1(string s)
    {
        n1 = s;
        Debug.Log(n1);
    }

    public void textedit2(string s)
    {
        n2 = s;
    }
    public static string n1="P_1";
    public static string n2="P_2";
    public void proceedToToss()
    {
        err1.enabled = false;
        err2.enabled = false;
        err3.enabled = false;
        if (n1.Trim()=="")
        {
            err1.enabled = true;
        }
           else if(n2.Trim()=="")
        {
            err2.enabled = true;
        }
           else if(a1+a2==6)
        {
            err3.enabled = true;
        }
           else
        {
            err1.enabled = false;
            err2.enabled = false;
            err3.enabled = false;
            Debug.Log("OK");
            Application.LoadLevel("toss_2");
        }
             
    }
}
