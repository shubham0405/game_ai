﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class sound_on_off : MonoBehaviour {

    public float vol;

    public void Start()
    {
        vol= PlayerPrefs.GetFloat("audio"); 
    }
    public void soundOff()
    {
        PlayerPrefs.SetFloat("audio", 0);
    }
    public void soundOn()
    {
        if(vol == 0)
            PlayerPrefs.SetFloat("audio", 1);
        else
            PlayerPrefs.SetFloat("audio", vol);
    }
}
