﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using System.IO;
using System;

public class random_points : MonoBehaviour {

    public GameObject[] spheres;
    public GameObject[] dots;//stores all the active points
    public GameObject[] lines;//stores all the cylinder
    public GameObject start;
    public GameObject end;
    //game area is divided into 4 lobies
    public GameObject[] lob1;
    public GameObject[] lob2;
    public GameObject[] lob3;
    public GameObject[] lob4;
    public int[,] conn;//2d array that store 1 if conection is between i and j
    public GameObject[,] cylinder;//store access to the cylinder between i and j
    public Material[] materials;
    public TextMesh data;
    public AudioSource sound;
    public AudioSource wins;
    public AudioSource draws;
    public int chance=0;
    public static string n1;
    public static string n2;
    int line_no=0;
    // Use this for initialization
    void Start () {
        int x;
        dots = new GameObject[27] ;
        conn = new int[27, 27];
        cylinder = new GameObject[27, 27];
        for (int i = 0; i < 27; i++)
        {
            for (int j = 0; j < 27; j++)
            {
                conn[i, j] = 0;
                cylinder[i, j] = null;
            }
        }
        dots[0] = start;
        dots[26] = end;
        dot_prod();
        //arrange dots in order
        for (int i=0;i<dots.Length;i++)
        {
            for(int j=0;j<dots.Length;j++)
            {
                if(dots[i].transform.position.x < dots[j].transform.position.x)
                {
                    GameObject temp = dots[i];
                    dots[i] = dots[j];
                    dots[j] = temp;
                }
            }
        }
        //make the lines between the dots
        for(int i=0;i<26;i++)
        {
            fun1(i);
            if (line_no > 61) break;
        }
        data.text = "Let's begin!";
       //add some more lines where there is empty space
        boundary();
        //ensure that atleast 3 lines from end and start dot
        ending(26);
        starting(0);
        //ensure that nearby cylinders are connected
        nearest();
        //remove cylinders where angle is less than 15 degree
        unwanted();
        boundary();
        chance = toss_script.chance;
        
        int t = toss_script.i;
        if((t==0  && chance==0)||(t==1 && chance==1))
        {
            n1 = Player_icon.n1;
            n2 = Player_icon.n2;
        }
        else
        {
            n2 = Player_icon.n1;
            n1 = Player_icon.n2;
        }
        // unwanted();
        // adv_des();
        // destructor();
        //destroyall();
    }
	//function to determine number of connection from each point randomly
    void fun1(int dot_no)
    {
        int num = UnityEngine.Random.Range(3, 4);
        if(dot_no!=0)
        {
            num= UnityEngine.Random.Range(2, 3);
        }
        if(dot_no >18)
        {
            num = UnityEngine.Random.Range(3, 4);
        }
        int link = 0;
        for(int i=dot_no+1 ; i<27 ; i++)
        {
            bool verdict = true;
            //ensure that angle of new line with others is more than 15 degree
            for(int j=dot_no+1;j<i;j++)
            {
                verdict = verdict && angle(dots[dot_no], dots[i], dots[j]) && angle(dots[j], dots[i], dots[dot_no]) && angle(dots[i], dots[dot_no], dots[j]);
            }
            if (verdict)
            {
                conn[dot_no, i] = 1;
                conn[i, dot_no] = 1;
                line(lines[line_no], dots[dot_no], dots[i]);
                cylinder[i, dot_no] = lines[line_no];
                cylinder[dot_no, i] = lines[line_no];
                link++;
                line_no++;
                if (link == num)
                    break;
                if (line_no > 61) break;
            }
            else
            {
                continue;
            }
        }
    }
    //to create line between two dots
    void line(GameObject cylinder,GameObject sphere1, GameObject sphere2)
    {
        cylinder.transform.localScale = new Vector3(0.15f, 1.0f, 0.15f);
        Vector3 dir = sphere2.transform.position - sphere1.transform.position;
        cylinder.transform.position = sphere1.transform.position + 0.5f * dir;
        Vector3 scale = cylinder.transform.localScale;
        scale.y = dir.magnitude * 0.5f;
        cylinder.transform.localScale = scale;
        cylinder.transform.rotation = Quaternion.FromToRotation(Vector3.up, dir);
    }
    //specifies whether the angle is less than or more than 15 degree
    bool angle(GameObject st,GameObject end,GameObject prev)
    {
        float dx21 = end.transform.position.x - st.transform.position.x;
        float dx31 = prev.transform.position.x - st.transform.position.x;
        float dy21 = end.transform.position.y - st.transform.position.y;
        float dy31 = prev.transform.position.y - st.transform.position.y;
        double m12 = Math.Sqrt(dx21 * dx21 + dy21 * dy21);
        double m13 = Math.Sqrt(dx31 * dx31 + dy31 * dy31);
        double theta = Math.Acos((dx21 * dx31 + dy21 * dy31) / (m12 * m13));
        theta = theta * 180 / Math.PI;
        if (theta > 180)
            theta = 360 - theta;
        if (theta > 14) { return true; }
        else
        {
            Debug.Log((int)theta);
            return false;
        }
    }

   /* void destroyall()
    {
        for(int i=0;i<10;i++)
        {
            for(int j=0;j<10;j++)
            {
                if(conn[i,j]==1)
                {
                    cylinder[i, j].active = false;
                }
            }
        }
    }*/

    /*void destructor()
    {
        for(int i=0;i<lines.Length;i++)
        {
            for(int j=i+1;j<lines.Length;j++)
            {
                if(lines[i].active==true && lines[j].active==true)
                if((Math.Abs(lines[i].transform.position.x-lines[j].transform.position.x) < 0.4 
                    && Math.Abs(lines[i].transform.position.y - lines[j].transform.position.y) < 0.4))
                {
                    if (lines[i].transform.localScale.y > lines[j].transform.localScale.y)
                        lines[i].active = false;
                    else
                        lines[j].active = false;
                }
            }
        }
    }*/

    void boundary()
    {
        bool cond=true;
        for(int i=0;i<dots.Length;i++ )
        {
            for(int j=i+3;j<dots.Length;j++)
            {
                cond = true;
                if (dots[i].transform.position.y > dots[i + 1].transform.position.y)
                {
                    for (int k = i + 1; k < j; k++)
                    {
                        if ((dots[i].transform.position.y > dots[k].transform.position.y) && (dots[j].transform.position.y > dots[k].transform.position.y))
                            cond = cond && true;
                        else
                            cond = false;
                    }
                }
                else
                {
                    for (int k = i + 1; k < j; k++)
                    {
                        if ((dots[i].transform.position.y < dots[k].transform.position.y) && (dots[j].transform.position.y < dots[k].transform.position.y))
                            cond = cond && true;
                        else
                            cond = false;
                    }
                }
                if (cond)
                {
                   // Debug.Log(j);
                    Vector3 dir = dots[j].transform.position - dots[i].transform.position;
                     bool exist = true;
                     for(int h=0;h<line_no;h++)
                     {
                           if(lines[h].transform.position == dots[i].transform.position + 0.5f * dir)
                           {
                               exist = false;
                               break;
                           }
                     }

                     if(exist)
                     {
                        bool verdict = true;
                        for (int f = i + 1; f < j; f++)
                        {
                            verdict = verdict && angle(dots[f], dots[i], dots[j]);
                        }
                       // verdict = verdict && angle(dots[i], dots[i+1], dots[j]);
                        //verdict = verdict && angle(dots[j], dots[i], dots[j-1]);
                        if (verdict)
                        {
                            line(lines[line_no], dots[j], dots[i]);
                            conn[j, i] = 1;
                            conn[i, j] = 1;
                            cylinder[i, j] = lines[line_no];
                            cylinder[j, i] = lines[line_no];
                            line_no++;
                            if (line_no > 100) break;
                        }
                     }
                }
                
           }
            
            if (line_no > 100) break;
        }
        
    }
    //to choose the dots randomly
    void dot_prod()
    {
        int x;
        bool pos = true; 
        int tries= 0;
        int left = 0;
        for (int i = 0; i < 5;)
        {
            pos = true;
            x = UnityEngine.Random.Range(0, lob1.Length - 1);
            if (lob1[x].active == false)
            {
                for(int k=0;k<=i;k++)
                {
                    if (Math.Abs(dots[k].transform.position.x - lob1[x].transform.position.x) < 2 &&
                        Math.Abs(dots[k].transform.position.y - lob1[x].transform.position.y) < 2)
                    {
                        pos = false;
                        break;
                    }
                    else
                        pos = true;
                }
                if (pos)
                {
                    lob1[x].active = true;
                    dots[i + 1] = lob1[x];
                    i++;
                }
            }
            tries++;
            if(tries>100) { left = 5 - i; break; }

        }
        tries = 0;
        for (int i = 5-left; i < 13;)
        {
            pos = true;
            left = 0;
            x = UnityEngine.Random.Range(0, lob2.Length - 1);
            if (lob2[x].active == false)
            {

                for (int k = 0; k <= i; k++)
                {
                    if (Math.Abs(dots[k].transform.position.x - lob2[x].transform.position.x) < 2.1 &&
                        Math.Abs(dots[k].transform.position.y - lob2[x].transform.position.y) < 2)
                    {
                        pos = false;
                        break;
                    }
                    else
                        pos = true;
                }
                if (pos)
                {
                    lob2[x].active = true;
                    dots[i + 1] = lob2[x];
                    i++;
                }
            }
            tries++;
            if (tries > 100) { left = 13 - i; break; }

        }
        tries = 0;
        for (int i = 13-left; i < 21;)
        {
            pos = true;
            left = 0;
            x = UnityEngine.Random.Range(0, lob3.Length - 1);
            if (lob3[x].active == false)
            {
                for (int k = 5; k <= i; k++)
                {
                    if (Math.Abs(dots[k].transform.position.x - lob3[x].transform.position.x) < 2.1 &&
                        Math.Abs(dots[k].transform.position.y - lob3[x].transform.position.y) < 2)
                    {
                        pos = false;
                        break;
                    }
                    else
                        pos = true;
                }
                if (pos)
                {
                    lob3[x].active = true;
                    dots[i + 1] = lob3[x];
                    i++;
                }
            }
            tries++;
            if (tries > 100) { left = 21 - i; break; }

        }
        tries = 0;
        for (int i = 21-left; i < 25;)
        {
            pos = true;
            left = 0;
            x = UnityEngine.Random.Range(0, lob4.Length - 1);
            if (lob4[x].active == false)
            {
                for (int k = 13; k <= i; k++)
                {
                    if (Math.Abs(dots[k].transform.position.x - lob4[x].transform.position.x) < 2 &&
                        Math.Abs(dots[k].transform.position.y - lob4[x].transform.position.y) < 2)
                    {
                        pos = false;
                        break;
                    }
                    else
                        pos = true;
                }
                if (pos)
                {
                    lob4[x].active = true;
                    dots[i + 1] = lob4[x];
                    i++;
                }
            }
            if (tries > 1000) break;

        }

    }

    void nearest()
    {
        for(int i=0;i<25;i++)
        {
            if(conn[i,i+1]==0)
            {
                conn[i+1, i] = 1;
                conn[i, i+1] = 1;
                line(lines[line_no], dots[1+i], dots[i]);
                cylinder[i, i+1] = lines[line_no];
                cylinder[i+1, i] = lines[line_no];
                line_no++;
            }
            if (conn[i, i + 2] == 0)
            {
                conn[i + 2, i] = 1;
                conn[i, i + 2] = 1;
                line(lines[line_no], dots[2 + i], dots[i]);
                cylinder[i, i + 2] = lines[line_no];
                cylinder[i + 2, i] = lines[line_no];
                line_no++;
            }
        }
    }
    void unwanted()
    {
        for(int i=0;i<27;i++)
        {
            for(int j=0;j<27;j++)
            {
                if(conn[i,j]==1)
                {
                    if(cylinder[i,j].transform.localScale.y>8)
                    {
                        conn[i, j] = -1;
                        conn[j, i] = -1;
                        cylinder[j, i].active = false;
                    }
                }
            }
        }
        for(int i=0;i<27;i++)
        {
            for(int j=0;j<27;j++)
            {
                if (i == j) continue;
                if(conn[i,j]==1)
                {
                    for(int k=0; k<27;k++)
                    {
                        if (k == i || k == j) continue;
                        if(conn[i,k]==1)
                        {
                            bool fate= angle(dots[i], dots[j], dots[k]);
                            if(!fate)
                            {
                                int gone = dist(j, k, i);
                                conn[i, gone] = -1;
                                conn[gone, i] = -1;
                                cylinder[gone, i].active = false;
                            }
                        }
                    }
                }
            }
        }
    }

    
    /*bool is_line(int i,int j)
    {
        Vector3 dir = dots[j].transform.position - dots[i].transform.position;
        bool exist = false;
        for (int h = 0; h < line_no; h++)
        {
            if (lines[h].transform.position == dots[i].transform.position + 0.5f * dir && lines[h].active == true)
            {
               
                    exist = true;
               
                break;
            }
        }
        return exist;
    }*/
    //return which line is longer
    int dist(int i,int j,int k)
    {
        float dis1 = Math.Abs(Vector3.Distance(dots[k].transform.position, dots[i].transform.position));
        float dis2 = Math.Abs( Vector3.Distance(dots[k].transform.position, dots[j].transform.position));
        if (dis1 > dis2) return i;
        else return j;
    }

   
    void ending(int x)
    {
        for(int i=23;i<26;i++)
        {
            if(conn[x,i]==0)
            {
                conn[x, i] = 1;
                conn[i, x] = 1;
                line(lines[line_no], dots[x], dots[i]);
                cylinder[i, x] = lines[line_no];
                cylinder[x, i] = lines[line_no];
                line_no++;
            }
        }
    }

    void starting(int x)
    {
        for (int i = 1; i < 5; i++)
        {
            if (conn[x, i] == 0)
            {
                conn[x, i] = 1;
                conn[i, x] = 1;
                line(lines[line_no], dots[x], dots[i]);
                cylinder[i, x] = lines[line_no];
                cylinder[x, i] = lines[line_no];
                line_no++;
            }
        }
    }
    /*void switchoff(int i,int j)
    {
        Vector3 dir = dots[j].transform.position - dots[i].transform.position;
        for (int h = 0; h < line_no; h++)
        {
            if (lines[h].transform.position == dots[i].transform.position + 0.5f * dir)
            {
                if(lines[h].active==true)
                lines[h].active = false;
                return;
            }
        }
        Debug.Log("busted");
    }*/


    /* void adv_des()
     {
         bool l1, l2, l3;
         for(int i=0;i<dots.Length;i++)
         {
             for(int j=0;j<dots.Length;j++)
             {
                 if (i == j) continue;
                 for(int k=0;k<dots.Length;k++)
                 {
                     l1 = l2 = l3 = true;
                     if (j == k || k == i) continue;
                     l1 = angle(dots[k], dots[i], dots[j]);
                     if(!l1)
                     {

                         l2 = is_line(Math.Min(k,i),Math.Max(k,i));
                         l3 = is_line(Math.Min(k, j), Math.Max(k, j));
                         if(l2 && l3)
                         {
                             int el = dist(i, j, k);
                             switchoff(Math.Min(k, el), Math.Max(k, el));
                             Debug.Log("                                 Deleted " + el +" " + k+ " " + (i+j-el));
                         }
                     }
                 }
             }
         }
     }*/

    public int[] win;
    public int d1=0,d2=0,draw=0;
    public int[] win2;
    public int text=1;
    public GameObject button1,button2,button3;
    public TextMesh drawtext;
    int count = 0,count2 =0,count3=0;
    // Update is called once per frame
    void Update()
    {
        sound.volume= PlayerPrefs.GetFloat("audio");
        wins.volume= PlayerPrefs.GetFloat("audio");
        draws.volume= PlayerPrefs.GetFloat("audio");
        if (chance == 0 && text ==1)
        {
            data.text = n1+"'s Turn";
            data.color = Color.blue;
        }
        else if (chance == 1 && text==1)
        {
            data.text = n2 + "'s Turn"; ;
            data.color = Color.red;
        }
        else if(text==2)
        {
            for (int i = 0; i < 27; i++) win[i] = -1;
            winning(10, 0, 1);
            for (int k = 0; k < 5; k++)
                for (int i=1;i<26;i++)
            {
                if(win[i]==1)
                {
                    int count = 0;
                    for(int j=0;j<27;j++)
                    {
                        if (conn[i, j] == 10)
                            count++;
                    }
                    if (count <= 1) win[i] = 0;
                }
            }
            for(int i=0;i<27;i++)
            {
                if(win[i]==1)
                {
                    for(int j=i+1;j<27;j++)
                    {
                        if(win[j]==1)
                        {
                            if(conn[i,j]==10)
                            {
                                if(cylinder[i,j].transform.localScale != new Vector3(0.25f,cylinder[i,j].transform.localScale.y,0.25f))
                                {
                                    cylinder[i, j].transform.localScale += new Vector3(0.005f, 0, 0.005f);
                                }
                                else
                                {
                                    data.text = n1+" Won !!";
                                    data.color = Color.blue;
                                }
                            }
                        }
                    }
                }
            }
            if (count2 == 0) wins.Play();
            count2++;
            data.text = n1 + " Won !!";
            data.color = Color.blue;
            int newpage = 0;
            for(int i=0;i<27;i++)
            {
                for (int j = 0; j < 27; j++)
                {
                    if (conn[i, j] == 10)
                    {
                        if (cylinder[i, j].transform.localScale == new Vector3(0.25f, cylinder[i, j].transform.localScale.y, 0.25f))
                        {
                            newpage = 1;
                        }
                    }
                }
            }
            if(newpage==1)
            {
                if (button1.active == false)
                    button1.active = true;
            }
        }
        else if(text==3)
        {
            for (int i = 0; i < 27; i++) win[i] = -1;
            winning(-10, 0, 1);
            for(int k=0;k<5;k++)

            for (int i = 1; i < 26; i++)
            {
                if (win[i] == 1)
                {
                    int count = 0;
                    for (int j = 0; j < 27; j++)
                    {
                        if (conn[i, j] == -10)
                            count++;
                    }
                    if (count <= 1) win[i] = 0;
                }
            }
            for (int i = 0; i < 27; i++)
            {
                if (win[i] == 1)
                {
                    for (int j = i + 1; j < 27; j++)
                    {
                        if (win[j] == 1)
                        {
                            if (conn[i, j] == -10)
                            {
                                if (cylinder[i, j].transform.localScale != new Vector3(0.25f, cylinder[i, j].transform.localScale.y, 0.25f))
                                {
                                    cylinder[i, j].transform.localScale += new Vector3(0.005f, 0, 0.005f);
                                }
                                else
                                {
                                    data.text = n2 + " Won !!";
                                    data.color = Color.red;
                                }
                            }
                        }
                    }
                }
            }
            if (count2 == 0) wins.Play();
            count2++;
            data.text = n2 + " Won !!";
            data.color = Color.red;
            int newpage = 0;
            for (int i = 0; i < 27; i++)
            {
                for (int j = 0; j < 27; j++)
                {
                    if (conn[i, j] == -10)
                    {
                        if (cylinder[i, j].transform.localScale == new Vector3(0.25f, cylinder[i, j].transform.localScale.y, 0.25f))
                        {
                            newpage = 1;
                        }
                    }
                }
            }
            if (newpage == 1)
            {
                if (button2.active == false)
                button2.active = true;
            }
        }
        else if(text==4)
        {
            if (count3 == 0) draws.Play();
            count3++;
            data.text = "Draw !!!";
            drawtext.text = "No One can win now !!";
            drawtext.color = Color.cyan;
                data.color = Color.green;
            if (button3.active == false)
                button3.active = true;
        }
        else
        {
            data.text = "ERROR";
            data.color = Color.cyan;
        }
        if (text == 1)
        {
            win = new int[27];
            for (int i = 0; i < 27; i++) win[i] = -1;

            winning(10, 0, 1);
            for (int i = 0; i < 27; i++) win[i] = -1;
            winning(-10, 0, 1);
        }
        bool flag = true;
        for (int i = 0; i < 27; i++)
        {
            for(int j=0;j<27;j++)
            {
                if (conn[i, j] == 1)
                    flag = false;
            }
        }
        if (flag)
        {
            text=4;
            return;
        }
        win2 = new int[27];
        if (d1 == 0)
        {
            for (int i = 0; i < 27; i++) win2[i] = -1;
            draw = 0;
            drawCheck(10, 0, 1);
            if (draw == 1) d1 = 0;
            else d1 = 1;
        }
        if (d2 == 0)
        {
            for (int i = 0; i < 27; i++) win2[i] = -1;
            draw = 0;
            drawCheck(-10, 0, 1);
            if (draw == 1) d2 = 0;
            else d2 = 1;
        }
        if (d1==1 && d2==1) text = 4;
        else if (d1 == 1)
            {
                drawtext.text = n1+" cannot win now ! But it may enforce draw";
                drawtext.color = Color.blue;
            if (count == 0)
                sound.Play();
            count++;
            }
        else    if (d2 == 1)
            {
                drawtext.text = n2+" cannot win now ! But it may enforce draw";
                drawtext.color = Color.red;
            if (count == 0)
                sound.Play();
            count++;
        }
        
    }

    void winning(int x,int curr,int depth)
    {
        
        if(curr==26 && x==10)
        {
            text = 2;
            return;
        }
        if (curr == 26 && x == -10)
        {
            text = 3;
            return;
        }
        if (depth == 35) return;
        for (int i = 0; i < 27; i++)
        {
            if (win[i] != 1)
            {
                if (conn[curr, i] == x)
                {
                    win[i] = 1;
                    winning(x, i, depth + 1);
                }
            }
            if (i == 26 && win[i] != 1 && curr!=0)
                win[curr] = 0;
        }
                   
    }
    void drawCheck(int x,int curr,int depth)
    {
        if (curr == 26)
        {
            draw = 1;
            return;
        }
        if (depth == 80) return;
        for (int i = 0; i < 27; i++)
        {
            if(win2[i]!=1)
                if (conn[curr, i] == x || conn[curr, i] == 1)
                {
                    win2[i] = 1;
                    drawCheck(x, i, depth + 1);
                }
            
        }
        

    }

    public GameObject t1,t2,can;
    public int[] arr;
    public void disableAll()
    {
        arr = new int[lines.Length];
        for (int i = 0; i < lines.Length; i++) arr[i] = 0;
        for(int i=0;i<dots.Length;i++)
        {
            if(dots[i].active == true)
            dots[i].active = false;
        }
        for(int i=0;i<lines.Length;i++)
        {
            if (lines[i].active == true)
                lines[i].active = false;
            else
            {
                arr[i] = 1;
            }

        }
        t1.active = false;
        t2.active = false;
        can.active = false;
    }

    public void enableAll()
    {
        for (int i = 0; i < dots.Length; i++)
        {
            if (dots[i].active == false)
                dots[i].active = true;
        }
        for (int i = 0; i < lines.Length; i++)
        {
            if (lines[i].active == false)
            {
                if (arr[i] == 0) lines[i].active = true;
            }

        }
        t1.active = true;
        t2.active = true;
        can.active = true;
    }
}
