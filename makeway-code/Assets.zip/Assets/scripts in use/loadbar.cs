﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using UnityEngine.SceneManagement;

public class loadbar : MonoBehaviour {

    public GameObject canvas;
    public Slider slider;
    public Text prog;
    public void loadlevel(int lvl)
    {
        canvas.active = true;
        StartCoroutine(loading(lvl));
    }
    IEnumerator loading(int lvl)
    {
        AsyncOperation operation = SceneManager.LoadSceneAsync(lvl);
        while(!operation.isDone)
        {
            float progress = Mathf.Clamp01(operation.progress / 0.9f);
            slider.value = progress;
            prog.text = (int)(progress * 100) + "%";
            Debug.Log(operation.progress);
            yield return null;
        }
    }
}
