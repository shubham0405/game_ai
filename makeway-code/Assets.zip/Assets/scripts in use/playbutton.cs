﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class playbutton : MonoBehaviour {

	public void changescene(string scenename)
    {
        Application.LoadLevel(scenename);
    }

    public void backscene(string scenename)
    {
        Application.LoadLevel(scenename);
    }

    public void exit()
    {
        Application.Quit();
    }
}
