﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class text_match : MonoBehaviour {

    public Text t1;
	// Use this for initialization
	void Start () {
        t1.text = random_points.n1 + " WON THE GAME !!";
	}
	
	// Update is called once per frame
	void Update () {
		
	}
}
