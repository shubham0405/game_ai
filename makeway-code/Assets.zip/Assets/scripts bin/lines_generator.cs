﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class lines_generator : MonoBehaviour {
    public GameObject[] lines;
    public GameObject[] spheres;
    public GameObject[] dots;
    public GameObject start;
    public GameObject end;
	// Use this for initialization
	void Start ()
    {
        int temp=1;
        dots = new GameObject[27];
        dots[0] = start;
        dots[26] = end;
        for(int i=0;i<spheres.Length;i++)
        {
            if(spheres[i].active == true)
            {
                dots[temp] = spheres[i];
                temp++;
            }
        }
        for (int i = 1; i < 26; i++)
        {
            for (int j = 1; j < 26; j++)
            {
                if (dots[i].transform.position.x < dots[j].transform.position.x)
                {
                    GameObject tem = dots[i];
                    dots[i] = dots[j];
                    dots[j] = tem;
                }
            }
        }
    }

    void random ()
    {

    }
	
	// Update is called once per frame
	void Update () {
		
	}
}
